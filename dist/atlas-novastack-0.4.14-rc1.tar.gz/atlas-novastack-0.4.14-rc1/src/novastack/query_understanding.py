"""Deterministic Query Understanding & Entity Recognition — Phase 4C-1.

Extracts structured enterprise signals from queries using deterministic
methods only (compiled regex, controlled vocabularies, ground-truth catalogs):
- Entity identification (Services, Teams, Customers, Incidents, Deployments, PRs, Events)
- Identifier recognition (INC-, DEP-, PR-, EVT-, SVC-, USR-, TEAM-, CUST-)
- Catalog-based alias resolution (e.g. 'checkout' -> 'checkout-service')
- Temporal constraint extraction (dates, ranges, sequence markers)
- Lifecycle/version constraints (latest, active, deprecated, superseded, v1-v3)
- Relationship signal extraction (owns, caused by, affects, deploys, fixes)
"""

from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

__all__ = [
    "AliasMention",
    "EntityCatalog",
    "EntityMention",
    "IdentifierMention",
    "LifecycleConstraint",
    "QueryUnderstanding",
    "QueryUnderstandingExtractor",
    "RelationshipSignal",
    "TemporalConstraint",
]

# Controlled Identifier Pattern
_ID_PATTERN = re.compile(
    r"\b(INC|DEP|PR|EVT|SVC|USR|TEAM|CUST|TKT|DOC)-[A-Z0-9-]+\b"
)

# Explicit Relationship Vocabulary
RELATIONSHIP_VERB_MAP: dict[str, str] = {
    "owned by": "owned_by",
    "owns": "owns",
    "caused by": "caused_by",
    "caused": "caused",
    "affects": "affects",
    "affected by": "affected_by",
    "contains": "contains",
    "contained in": "contained_in",
    "related to": "related_to",
    "documented by": "documented_by",
    "discussed in": "discussed_in",
    "deployed in": "deployed_in",
    "deploys": "deploys",
    "deployed": "deployed",
    "fixed by": "fixed_by",
    "fixes": "fixes",
    "escalation": "escalated_to",
}

# Explicit Temporal Markers
TEMPORAL_MARKERS = [
    "before",
    "after",
    "during",
    "between",
    "timeline",
    "duration",
    "how long",
    "as of",
    "historical",
    "latest",
    "current",
    "most recent",
]

# Explicit Lifecycle Markers
LIFECYCLE_MARKERS = [
    "latest",
    "current",
    "active",
    "published",
    "deprecated",
    "superseded",
    "previous",
    "historical",
    "version",
    "v1",
    "v2",
    "v3",
]


@dataclass
class EntityMention:
    """An entity recognized from the query text."""

    entity_type: str  # service, team, customer, incident, deployment, pull_request, event
    entity_id: str
    matched_text: str
    match_method: str  # exact_name, exact_id, alias


@dataclass
class IdentifierMention:
    """An exact formal identifier recognized in the query."""

    identifier_type: str  # INC, DEP, PR, EVT, SVC, USR, TEAM, CUST, etc.
    identifier: str
    matched_text: str


@dataclass
class AliasMention:
    """A recognized enterprise alias mapped to its canonical entity ID."""

    canonical_entity_id: str
    alias: str
    matched_text: str


@dataclass
class TemporalConstraint:
    """An extracted temporal constraint."""

    type: str  # date, interval, relative_sequence, recency
    value: str
    start: str | None = None
    end: str | None = None


@dataclass
class LifecycleConstraint:
    """Extracted lifecycle and version constraint signals."""

    latest: bool = False
    active: bool = False
    published: bool = False
    deprecated: bool = False
    superseded: bool = False
    version: str | None = None


@dataclass
class RelationshipSignal:
    """An extracted relationship phrase connecting enterprise entities."""

    relationship_type: str
    subject_entity: str | None
    object_entity: str | None
    matched_phrase: str


@dataclass
class QueryUnderstanding:
    """Structured deterministic query-understanding output for an evaluation case."""

    evaluation_id: str
    original_query: str
    normalized_query: str
    entities: list[EntityMention] = field(default_factory=list)
    identifiers: list[IdentifierMention] = field(default_factory=list)
    aliases: list[AliasMention] = field(default_factory=list)
    temporal_constraints: list[TemporalConstraint] = field(default_factory=list)
    lifecycle_constraints: LifecycleConstraint = field(default_factory=LifecycleConstraint)
    relationship_signals: list[RelationshipSignal] = field(default_factory=list)
    expanded_query: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert QueryUnderstanding object to JSON-compatible dictionary."""
        return {
            "evaluation_id": self.evaluation_id,
            "original_query": self.original_query,
            "normalized_query": self.normalized_query,
            "entities": [asdict(e) for e in self.entities],
            "identifiers": [asdict(i) for i in self.identifiers],
            "aliases": [asdict(a) for a in self.aliases],
            "temporal_constraints": [asdict(t) for t in self.temporal_constraints],
            "lifecycle_constraints": asdict(self.lifecycle_constraints),
            "relationship_signals": [asdict(r) for r in self.relationship_signals],
            "expanded_query": self.expanded_query,
        }


class EntityCatalog:
    """Deterministic catalog index built directly from NovaStack ground-truth entity files."""

    def __init__(self, raw_data_dir: Path) -> None:
        self.raw_dir = raw_data_dir

        # Maps
        self.id_to_entity: dict[str, dict[str, Any]] = {}
        self.name_to_entity: dict[str, dict[str, Any]] = {}
        self.alias_to_entity_id: dict[str, str] = {}

        self._load_catalogs()
        self._build_alias_rules()

    def _load_catalogs(self) -> None:
        # 1. Services
        svc_path = self.raw_dir / "services.json"
        if svc_path.exists():
            with open(svc_path, "r", encoding="utf-8") as f:
                for s in json.load(f).get("services", []):
                    data = {"type": "service", "id": s["service_id"], "name": s["name"], "owner_team_id": s.get("owner_team_id")}
                    self.id_to_entity[s["service_id"]] = data
                    self.name_to_entity[s["name"].lower()] = data

        # 2. Teams
        team_path = self.raw_dir / "teams.json"
        if team_path.exists():
            with open(team_path, "r", encoding="utf-8") as f:
                for t in json.load(f).get("teams", []):
                    data = {"type": "team", "id": t["team_id"], "name": t["name"], "department": t.get("department")}
                    self.id_to_entity[t["team_id"]] = data
                    self.name_to_entity[t["name"].lower()] = data

        # 3. Incidents
        inc_path = self.raw_dir / "incidents.json"
        if inc_path.exists():
            with open(inc_path, "r", encoding="utf-8") as f:
                for i in json.load(f).get("incidents", []):
                    data = {"type": "incident", "id": i["incident_id"], "title": i.get("title", ""), "service_id": i.get("service_id")}
                    self.id_to_entity[i["incident_id"]] = data

        # 4. Deployments
        dep_path = self.raw_dir / "deployments.json"
        if dep_path.exists():
            with open(dep_path, "r", encoding="utf-8") as f:
                for d in json.load(f).get("deployments", []):
                    data = {"type": "deployment", "id": d["deployment_id"], "service_id": d.get("service_id"), "version": d.get("version")}
                    self.id_to_entity[d["deployment_id"]] = data

        # 5. Pull Requests
        pr_path = self.raw_dir / "pull_requests.json"
        if pr_path.exists():
            with open(pr_path, "r", encoding="utf-8") as f:
                for p in json.load(f).get("pull_requests", []):
                    data = {"type": "pull_request", "id": p["pull_request_id"], "service_id": p.get("service_id"), "title": p.get("title", "")}
                    self.id_to_entity[p["pull_request_id"]] = data

        # 6. Events
        evt_path = self.raw_dir / "events.json"
        if evt_path.exists():
            with open(evt_path, "r", encoding="utf-8") as f:
                for e in json.load(f).get("events", []):
                    data = {"type": "event", "id": e["event_id"], "title": e.get("title", "")}
                    self.id_to_entity[e["event_id"]] = data

        # 7. Customers
        cust_path = self.raw_dir / "customers.json"
        if cust_path.exists():
            with open(cust_path, "r", encoding="utf-8") as f:
                for c in json.load(f).get("customers", []):
                    data = {"type": "customer", "id": c["customer_id"], "name": c["name"]}
                    self.id_to_entity[c["customer_id"]] = data
                    self.name_to_entity[c["name"].lower()] = data

    def _build_alias_rules(self) -> None:
        """Deterministic, testable alias rules derived from service names and common terms."""
        # For services ending in '-service', strip suffix to create service alias
        # e.g. 'checkout-service' -> alias 'checkout'
        for name, ent in list(self.name_to_entity.items()):
            if ent["type"] == "service" and name.endswith("-service"):
                base_alias = name[:-8]  # strip '-service'
                if len(base_alias) >= 3:
                    self.alias_to_entity_id[base_alias] = ent["id"]

        # Common unambiguous enterprise alias mappings
        explicit_aliases = {
            "checkout": "SVC-NS-0005",
            "payments": "SVC-NS-0007",
            "payment": "SVC-NS-0007",
            "auth": "SVC-NS-0006",
            "authentication": "SVC-NS-0006",
            "media": "SVC-NS-0009",
            "cart": "SVC-NS-0008",
            "notification": "SVC-NS-0010",
            "notifications": "SVC-NS-0010",
            "feature-flags": "SVC-NS-0001",
            "flags": "SVC-NS-0001",
            "analytics": "SVC-NS-0002",
            "data warehouse": "SVC-NS-0003",
            "warehouse": "SVC-NS-0003",
            "email": "SVC-NS-0004",
            "inventory": "SVC-NS-0011",
            "search": "SVC-NS-0012",
            "recommendation": "SVC-NS-0013",
            "billing": "SVC-NS-0014",
            "shipping": "SVC-NS-0015",
            "sre": "TEAM-NS-0005",
            "devops": "TEAM-NS-0004",
            "security": "TEAM-NS-0007",
        }
        for alias, s_id in explicit_aliases.items():
            if s_id in self.id_to_entity:
                self.alias_to_entity_id[alias] = s_id


class QueryUnderstandingExtractor:
    """Deterministic extractor for query understanding signals."""

    def __init__(self, catalog: EntityCatalog) -> None:
        self.catalog = catalog

    def extract(self, evaluation_id: str, query: str) -> QueryUnderstanding:
        """Extract structured entities, identifiers, aliases, and constraints from query."""
        normalized_q = query.strip()

        entities: list[EntityMention] = []
        identifiers: list[IdentifierMention] = []
        aliases: list[AliasMention] = []
        temporal: list[TemporalConstraint] = []
        relationship_signals: list[RelationshipSignal] = []

        seen_entities: set[str] = set()

        # 1. Exact Identifiers
        for m in _ID_PATTERN.finditer(query):
            matched_id = m.group(0)
            prefix = matched_id.split("-")[0]
            identifiers.append(
                IdentifierMention(
                    identifier_type=prefix,
                    identifier=matched_id,
                    matched_text=matched_id,
                )
            )
            # If in catalog, also record as entity
            if matched_id in self.catalog.id_to_entity:
                ent_info = self.catalog.id_to_entity[matched_id]
                if matched_id not in seen_entities:
                    entities.append(
                        EntityMention(
                            entity_type=ent_info["type"],
                            entity_id=matched_id,
                            matched_text=matched_id,
                            match_method="exact_id",
                        )
                    )
                    seen_entities.add(matched_id)

        # 2. Exact Names & Aliases
        q_lower = query.lower()

        # Check full catalog names (longer names first to avoid partial matches)
        sorted_names = sorted(self.catalog.name_to_entity.keys(), key=len, reverse=True)
        for name in sorted_names:
            pattern = rf"\b{re.escape(name)}\b"
            m = re.search(pattern, q_lower)
            if m:
                ent_info = self.catalog.name_to_entity[name]
                e_id = ent_info["id"]
                if e_id not in seen_entities:
                    entities.append(
                        EntityMention(
                            entity_type=ent_info["type"],
                            entity_id=e_id,
                            matched_text=m.group(0),
                            match_method="exact_name",
                        )
                    )
                    seen_entities.add(e_id)

        # Check aliases
        sorted_aliases = sorted(self.catalog.alias_to_entity_id.keys(), key=len, reverse=True)
        for alias in sorted_aliases:
            pattern = rf"\b{re.escape(alias)}\b"
            m = re.search(pattern, q_lower)
            if m:
                e_id = self.catalog.alias_to_entity_id[alias]
                aliases.append(
                    AliasMention(
                        canonical_entity_id=e_id,
                        alias=alias,
                        matched_text=m.group(0),
                    )
                )
                if e_id not in seen_entities and e_id in self.catalog.id_to_entity:
                    ent_info = self.catalog.id_to_entity[e_id]
                    entities.append(
                        EntityMention(
                            entity_type=ent_info["type"],
                            entity_id=e_id,
                            matched_text=m.group(0),
                            match_method="alias",
                        )
                    )
                    seen_entities.add(e_id)

        # 3. Temporal Constraints
        # Explicit date match: YYYY-MM-DD or YYYY-MM or YYYY
        date_matches = re.finditer(r"\b(20\d{2})(?:-(\d{2}))?(?:-(\d{2}))?\b", query)
        for dm in date_matches:
            temporal.append(
                TemporalConstraint(
                    type="explicit_date",
                    value=dm.group(0),
                    start=dm.group(0),
                    end=dm.group(0),
                )
            )

        for marker in TEMPORAL_MARKERS:
            pattern = rf"\b{re.escape(marker)}\b"
            m = re.search(pattern, q_lower)
            if m:
                temporal.append(
                    TemporalConstraint(
                        type="relative_marker",
                        value=marker,
                    )
                )

        # 4. Lifecycle Constraints
        lifecycle = LifecycleConstraint()
        if re.search(r"\blatest\b", q_lower):
            lifecycle.latest = True
        if re.search(r"\bcurrent\b|\bactive\b", q_lower):
            lifecycle.active = True
        if re.search(r"\bpublished\b", q_lower):
            lifecycle.published = True
        if re.search(r"\bdeprecated\b", q_lower):
            lifecycle.deprecated = True
        if re.search(r"\bsuperseded\b", q_lower):
            lifecycle.superseded = True

        ver_match = re.search(r"\bv\d+(\.\d+)*\b|\bversion\s+(\d+(\.\d+)*)\b", q_lower)
        if ver_match:
            lifecycle.version = ver_match.group(0)

        # 5. Relationship Signals
        for verb_phrase, rel_type in RELATIONSHIP_VERB_MAP.items():
            pattern = rf"\b{re.escape(verb_phrase)}\b"
            m = re.search(pattern, q_lower)
            if m:
                # Associate subject and object if available from recognized entities
                subj = entities[0].entity_id if len(entities) > 0 else None
                obj = entities[1].entity_id if len(entities) > 1 else None
                relationship_signals.append(
                    RelationshipSignal(
                        relationship_type=rel_type,
                        subject_entity=subj,
                        object_entity=obj,
                        matched_phrase=m.group(0),
                    )
                )

        # 6. Construct Expanded Lexical Query
        # Augment original query with recognized canonical entity IDs and names
        exp_tokens = []
        for ent in entities:
            # Add entity ID
            if ent.entity_id not in exp_tokens:
                exp_tokens.append(ent.entity_id)
            # Add canonical name if not already in query
            if ent.entity_id in self.catalog.id_to_entity:
                canon_name = self.catalog.id_to_entity[ent.entity_id].get("name", "")
                if canon_name and canon_name.lower() not in q_lower and canon_name not in exp_tokens:
                    exp_tokens.append(canon_name)
                # If service, also add owner team ID
                owner_team = self.catalog.id_to_entity[ent.entity_id].get("owner_team_id")
                if owner_team and owner_team not in exp_tokens:
                    exp_tokens.append(owner_team)

        for id_men in identifiers:
            if id_men.identifier not in exp_tokens:
                exp_tokens.append(id_men.identifier)

        if exp_tokens:
            expanded_q = f"{normalized_q} {' '.join(exp_tokens)}"
        else:
            expanded_q = normalized_q

        return QueryUnderstanding(
            evaluation_id=evaluation_id,
            original_query=query,
            normalized_query=normalized_q,
            entities=entities,
            identifiers=identifiers,
            aliases=aliases,
            temporal_constraints=temporal,
            lifecycle_constraints=lifecycle,
            relationship_signals=relationship_signals,
            expanded_query=expanded_q,
        )
